import { describe, expect, test, vi } from 'vitest'
import { startAfterDesignReady } from './design-startup'
import type { DesignStartupProbe } from './design-startup'

function harness() {
    let after = () => {}
    let now = 1000
    const timers = new Map<number, () => void>()
    let next = 0
    const unsubscribe = vi.fn()
    const start = vi.fn()
    const fail = vi.fn()
    const probe = vi.fn<() => DesignStartupProbe>(() => ({
        state: 'pending',
        reason: 'path-missing',
    }))
    const schedule = vi.fn((callback: () => void, _delay: number) => {
        timers.set(++next, callback)
        return next
    })
    const cancel = vi.fn((id: unknown) => {
        timers.delete(id as number)
    })
    const stop = startAfterDesignReady({
        onAfter: callback => {
            after = callback
            return unsubscribe
        },
        start,
        fail,
        probe,
        schedule,
        cancel,
        now: () => now,
    })
    return {
        start,
        fail,
        probe,
        schedule,
        cancel,
        unsubscribe,
        stop,
        after: () => after(),
        advance: (ms: number) => {
            now += ms
        },
        tick: () => {
            const entry = timers.entries().next().value
            if (entry) {
                timers.delete(entry[0])
                entry[1]()
            }
        },
        pending: () => timers.size,
    }
}
describe('bounded post-render design startup', () => {
    test('does not probe or start when the timer runs beyond the deadline', () => {
        const h = harness()
        h.after()
        h.advance(5001)
        h.probe.mockReturnValue({ state: 'ready' })
        h.tick()
        expect(h.probe).not.toHaveBeenCalled()
        expect(h.start).not.toHaveBeenCalled()
        expect(h.fail).toHaveBeenCalledTimes(1)
    })
    test('does not probe or start at registration time', () => {
        const h = harness()
        expect(h.probe).not.toHaveBeenCalled()
        expect(h.schedule).not.toHaveBeenCalled()
        expect(h.start).not.toHaveBeenCalled()
    })
    test('defers inspection until after the runApplication callback returns', () => {
        const h = harness()
        h.after()
        expect(h.schedule).toHaveBeenCalledWith(expect.any(Function), 0)
        expect(h.probe).not.toHaveBeenCalled()
    })
    test('waits without starting when the path is missing', () => {
        const h = harness()
        h.after()
        h.tick()
        expect(h.start).not.toHaveBeenCalled()
        expect(h.fail).not.toHaveBeenCalled()
        expect(h.schedule).toHaveBeenLastCalledWith(expect.any(Function), 50)
    })
    test('starts exactly once when initialized exports become ready', () => {
        const h = harness()
        h.after()
        h.tick()
        h.probe.mockReturnValue({ state: 'ready', id: 15809 })
        h.tick()
        h.after()
        h.tick()
        expect(h.start).toHaveBeenCalledTimes(1)
        expect(h.fail).not.toHaveBeenCalled()
        expect(h.pending()).toBe(0)
    })
    test('does not create another timer for repeated startup events', () => {
        const h = harness()
        h.after()
        h.after()
        expect(h.schedule).toHaveBeenCalledTimes(1)
    })
    test('fails closed for invalid initialized exports', () => {
        const h = harness()
        h.probe.mockReturnValue({
            state: 'invalid',
            id: 15809,
            reason: 'missing-Text',
        })
        h.after()
        h.tick()
        expect(h.start).not.toHaveBeenCalled()
        expect(h.fail).toHaveBeenCalledWith(
            'Compatibility fix v5: module 15809 rejected (missing-Text).',
        )
        expect(h.pending()).toBe(0)
    })
    test('does not retry invalid namespaces', () => {
        const h = harness()
        h.probe.mockReturnValue({
            state: 'invalid',
            id: 31,
            reason: 'namespace-type',
        })
        h.after()
        h.tick()
        h.after()
        h.tick()
        expect(h.probe).toHaveBeenCalledTimes(1)
        expect(h.fail).toHaveBeenCalledTimes(1)
    })
    test('ends pending lookups after the five-second cutoff', () => {
        const h = harness()
        h.after()
        h.tick()
        h.advance(5000)
        h.tick()
        expect(h.start).not.toHaveBeenCalled()
        expect(h.fail).toHaveBeenCalledWith(
            'Compatibility fix v5: timed out waiting for design/native.tsx (path-missing).',
        )
        expect(h.pending()).toBe(0)
    })
    test('does not time out just before the cutoff', () => {
        const h = harness()
        h.after()
        h.advance(4999)
        h.tick()
        expect(h.fail).not.toHaveBeenCalled()
        expect(h.pending()).toBe(1)
    })
    test('accepts readiness observed at the cutoff', () => {
        const h = harness()
        h.after()
        h.advance(5000)
        h.probe.mockReturnValue({ state: 'ready' })
        h.tick()
        expect(h.start).toHaveBeenCalledTimes(1)
        expect(h.fail).not.toHaveBeenCalled()
    })
    test('contains inspection errors without exposing their messages', () => {
        const h = harness()
        h.probe.mockImplementation(() => {
            throw new Error('secret-token-marker')
        })
        h.after()
        h.tick()
        expect(h.start).not.toHaveBeenCalled()
        expect(h.fail).toHaveBeenCalledWith(
            'Compatibility fix v5: readiness inspection failed.',
        )
    })
    test('cancellation clears the pending timer and prevents startup', () => {
        const h = harness()
        h.after()
        h.stop()
        h.tick()
        h.after()
        expect(h.pending()).toBe(0)
        expect(h.start).not.toHaveBeenCalled()
        expect(h.probe).not.toHaveBeenCalled()
    })
    test('cancellation before startup prevents later scheduling', () => {
        const h = harness()
        h.stop()
        h.after()
        expect(h.schedule).not.toHaveBeenCalled()
    })
})
