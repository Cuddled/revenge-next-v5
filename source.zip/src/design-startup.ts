export interface DesignStartupProbe {
    state: 'pending' | 'invalid' | 'ready'
    reason?: string
    id?: number
}
export interface DesignStartupHooks {
    onAfter: (callback: () => void) => () => void
    probe: () => DesignStartupProbe
    start: () => void
    fail: (message: string) => void
    schedule: (callback: () => void, delayMs: number) => unknown
    cancel: (timer: unknown) => void
    now: () => number
}

/** Starts once after Discord returns and its exact design module is ready. */
export function startAfterDesignReady(hooks: DesignStartupHooks) {
    let started = false,
        stopped = false,
        deadline = 0
    let lastReason = 'path-missing'
    let timer: unknown
    let unsubscribe = () => {}

    function stop() {
        if (stopped) return
        stopped = true
        unsubscribe()
        if (timer !== undefined) hooks.cancel(timer)
    }

    function check() {
        timer = undefined
        if (stopped) return
        if (hooks.now() > deadline) {
            stop()
            hooks.fail(
                `Compatibility fix v5: timed out waiting for design/native.tsx (${lastReason}).`,
            )
            return
        }
        let result: DesignStartupProbe
        try {
            result = hooks.probe()
        } catch {
            stop()
            hooks.fail('Compatibility fix v5: readiness inspection failed.')
            return
        }
        if (result.state === 'ready') {
            stop()
            hooks.start()
        } else if (result.state === 'invalid') {
            stop()
            hooks.fail(
                `Compatibility fix v5: module ${result.id} rejected (${result.reason}).`,
            )
        } else if (hooks.now() >= deadline) {
            stop()
            hooks.fail(
                `Compatibility fix v5: timed out waiting for design/native.tsx (${result.reason}).`,
            )
        } else {
            lastReason = result.reason ?? 'pending'
            timer = hooks.schedule(check, 50)
        }
    }

    unsubscribe = hooks.onAfter(() => {
        if (started || stopped) return
        started = true
        deadline = hooks.now() + 5000
        unsubscribe()
        timer = hooks.schedule(check, 0)
    })

    return stop
}
