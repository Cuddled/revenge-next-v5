import { beforeEach, describe, expect, test, vi } from 'vitest'
import type { Filter } from '@revenge-mod/modules/finders/filters'

const runtime = vi.hoisted(() => {
    Object.assign(globalThis, {
        __DEV__: false,
        __BUILD_FLAG_DEBUG_MODULE_LOOKUPS__: false,
        __BUILD_FLAG_DEBUG_LAZY_VALUES__: false,
    })
    return {
        deps: new Map<number, number[]>(),
        exports: new Map<number, unknown>(),
        filters: new Map<string, Filter>(),
        assets: new Map<string, number>(),
        factories: [] as Array<() => unknown>,
    }
})
const metroUtils = {
    getModuleDependencies: (id: number) => runtime.deps.get(id) ?? [],
    getInitializedModuleExports: (id: number) => runtime.exports.get(id),
    isModuleInitialized: (id: number) => (runtime.exports.has(id) ? 1 : 0),
    isModuleExportBad: (value: unknown) => value == null,
}
vi.mock('@revenge-mod/modules/metro/utils', () => metroUtils)
vi.mock('../lib/modules/src/metro/utils', () => metroUtils)
const stub = () => {}
const finder = {
    lookupModule: (filter: Filter) => {
        runtime.filters.set(filter.key, filter)
        return [
            {
                open: (_value: unknown) => {},
                close: () => {},
                FlashList: stub,
            },
            700,
        ]
    },
    lookupModules: function* (filter: Filter) {
        runtime.filters.set(filter.key, filter)
        yield [{ open: (_value: unknown) => {}, close: () => {} }, 700]
    },
}
vi.mock('@revenge-mod/modules/finders', () => finder)
vi.mock('../lib/modules/src/finders/lookup', () => finder)
vi.mock('@revenge-mod/utils/proxy', () => ({
    proxify: (factory: () => unknown) => {
        runtime.factories.push(factory)
        return []
    },
}))
vi.mock('@revenge-mod/react', () => ({
    ReactModuleId: 19,
    ReactNativeModuleId: 27,
    ReactJSXRuntimeModuleId: 21,
}))
vi.mock('../lib/discord/src/common/flux', () => ({ DispatcherModuleId: 709 }))
vi.mock('@revenge-mod/discord/common/import-tracker', () => ({
    ImportTrackerModuleId: 2,
}))
vi.mock('../lib/discord/src/common/import-tracker', () => ({
    ImportTrackerModuleId: 2,
}))
vi.mock('@revenge-mod/discord/common/tokens', () => ({ TokensModuleId: 90 }))
vi.mock('@revenge-mod/assets', () => ({
    getAssetByName: (name: string) => {
        const moduleId = runtime.assets.get(name)
        return moduleId === undefined ? undefined : { moduleId }
    },
}))
beforeEach(() => {
    vi.resetModules()
    runtime.deps.clear()
    runtime.exports.clear()
    runtime.filters.clear()
    runtime.assets.clear()
    runtime.factories.length = 0
    runtime.deps.set(700, [709, 2])
})
function define(id: number, deps: number[], value: unknown) {
    runtime.deps.set(id, deps)
    runtime.exports.set(id, value)
}
function matches(filter: Filter, id: number) {
    return filter(id, runtime.exports.get(id), true)
}
async function toastFilter() {
    await import('@revenge-mod/discord/actions')
    runtime.factories.at(-1)!()
    const filter = runtime.filters.get(
        'revenge.discord.actions.ToastActionCreators.compat347.v5',
    )
    expect(filter).toBeDefined()
    return filter!
}
async function flashFilter() {
    await import('@revenge-mod/externals/shopify')
    runtime.factories.at(-1)!()
    const filter = runtime.filters.get(
        'revenge.externals.Shopify.FlashList.compat347.v5',
    )
    expect(filter).toBeDefined()
    return filter!
}
describe('restored upstream legacy toast filter', () => {
    test('matches the old Dispatcher and ImportTracker layout', async () => {
        const filter = await toastFilter()
        define(1000, [709, 2], { open: () => {}, close: () => {} })
        expect(matches(filter, 1000)).toBe(true)
    })
    test('rejects the similar initializer module', async () => {
        const filter = await toastFilter()
        define(1000, [709, 2], {
            open: () => {},
            close: () => {},
            init: () => {},
        })
        expect(matches(filter, 1000)).toBe(false)
    })
    test('requires both open and close', async () => {
        const filter = await toastFilter()
        define(1000, [709, 2], { open: () => {} })
        expect(matches(filter, 1000)).toBe(false)
    })
    test('rejects unrelated dependency IDs', async () => {
        const filter = await toastFilter()
        define(1000, [708, 2], { open: () => {}, close: () => {} })
        expect(matches(filter, 1000)).toBe(false)
    })
    test('rejects a longer unrelated legacy layout', async () => {
        const filter = await toastFilter()
        define(1000, [709, 2, 444], { open: () => {}, close: () => {} })
        expect(matches(filter, 1000)).toBe(false)
    })
    test('retains the newer short layout', async () => {
        const filter = await toastFilter()
        define(1000, [1001, 2], {
            open: (_value: unknown) => {},
            close: () => {},
        })
        define(1001, [2, 1002], {})
        expect(matches(filter, 1000)).toBe(true)
    })
    test('retains the intermediate layout', async () => {
        const filter = await toastFilter()
        define(1000, [1001, 1999, 1500, 709, 2], {
            open: () => {},
            close: () => {},
        })
        define(1001, [2, 1002], {})
        define(1500, [1501, 2], {})
        expect(matches(filter, 1000)).toBe(true)
    })
    test('uses a distinct cache key from v4', async () => {
        const filter = await toastFilter()
        expect(filter.key).not.toBe(
            'revenge.discord.actions.ToastActionCreators',
        )
    })
})
describe('restored upstream FlashList filter', () => {
    test('matches the nine-dependency legacy layout', async () => {
        const filter = await flashFilter()
        define(2000, [19, 27, 21, 101, 102, 103, 104, 105, 2], {
            FlashList: stub,
        })
        expect(matches(filter, 2000)).toBe(true)
    })
    test('rejects the wrong React dependency', async () => {
        const filter = await flashFilter()
        define(2000, [18, 27, 21, 101, 102, 103, 104, 105, 2], {
            FlashList: stub,
        })
        expect(matches(filter, 2000)).toBe(false)
    })
    test('rejects a mismatched dependency count', async () => {
        const filter = await flashFilter()
        define(2000, [19, 27, 21, 101, 102, 103, 104, 105, 2, 106], {
            FlashList: stub,
        })
        expect(matches(filter, 2000)).toBe(false)
    })
    test('requires the named FlashList export', async () => {
        const filter = await flashFilter()
        define(2000, [19, 27, 21, 101, 102, 103, 104, 105, 2], {})
        expect(matches(filter, 2000)).toBe(false)
    })
    test('retains the newer relative layout', async () => {
        const filter = await flashFilter()
        define(2000, [2001, 2002, 2003, 999], { FlashList: stub })
        define(2001, [27], {})
        define(2003, [2004], {})
        expect(matches(filter, 2000)).toBe(true)
    })
})
describe('restored upstream generated icon filter', () => {
    test('matches the old single-icon tail', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        runtime.assets.set('LegacyIcon', 500)
        define(3000, [19, 21, 90, 111, 500, 2], { LegacyIcon: stub })
        expect(matches(withGeneratedIconComponent('LegacyIcon'), 3000)).toBe(
            true,
        )
    })
    test('retains the newer single-icon tail', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        runtime.assets.set('NewIcon', 500)
        define(3000, [19, 21, 90, 500, 111, 2], { NewIcon: stub })
        expect(matches(withGeneratedIconComponent('NewIcon'), 3000)).toBe(true)
    })
    test('matches legacy multi-asset order', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        runtime.assets.set('second', 600)
        runtime.assets.set('first', 500)
        define(3000, [19, 27, 21, 90, 111, 600, 500, 2], {
            MultiIcon: stub,
        })
        expect(
            matches(
                withGeneratedIconComponent('MultiIcon', 'second', 'first'),
                3000,
            ),
        ).toBe(true)
    })
    test('retains newer sorted multi-asset order', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        runtime.assets.set('second', 600)
        runtime.assets.set('first', 500)
        define(3000, [19, 27, 21, 90, 500, 111, 600, 2], {
            MultiIcon: stub,
        })
        expect(
            matches(
                withGeneratedIconComponent('MultiIcon', 'second', 'first'),
                3000,
            ),
        ).toBe(true)
    })
    test('rejects wrong asset IDs', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        runtime.assets.set('Icon', 500)
        define(3000, [19, 21, 90, 111, 501, 2], { Icon: stub })
        expect(matches(withGeneratedIconComponent('Icon'), 3000)).toBe(false)
    })
    test('does not match missing assets', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        define(3000, [19, 21, 90, 111, 500, 2], { Icon: stub })
        expect(matches(withGeneratedIconComponent('MissingIcon'), 3000)).toBe(
            false,
        )
    })
    test('rejects empty initialized exports', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        runtime.assets.set('Icon', 500)
        define(3000, [19, 21, 90, 111, 500, 2], null)
        expect(matches(withGeneratedIconComponent('Icon'), 3000)).toBe(false)
    })
    test('uses a distinct generated-icon cache key', async () => {
        const { withGeneratedIconComponent } = await import(
            '@revenge-mod/utils/discord'
        )
        expect(withGeneratedIconComponent('Icon').key).toBe(
            'revenge.utils.discord.generatedIconComponent.compat347.v5(Icon)',
        )
    })
})
