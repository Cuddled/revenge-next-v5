// Initialize init libraries
import '@revenge-mod/react/init'
import '@revenge-mod/json-storage/init'

import { getDesignReadiness } from '@revenge-mod/discord/design/ready'
import { onRunApplicationFinished } from '@revenge-mod/react/native'
import { onError } from '~index'
import { startAfterDesignReady } from './design-startup'

startAfterDesignReady({
    onAfter: onRunApplicationFinished,
    probe: getDesignReadiness,
    schedule: (callback, delayMs) => setTimeout(callback, delayMs),
    cancel: timer => clearTimeout(timer as ReturnType<typeof setTimeout>),
    now: () => Date.now(),
    fail: message => onError(new Error(message)),
    start: () => {
        try {
            // @as-require
            import('./start')
        } catch (e) {
            onError(e)
        }
    },
})

// Run all init plugins
// @as-require
import '~/plugins/init'
// @as-require
import '@revenge-mod/plugins/init'
