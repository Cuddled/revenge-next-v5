import { beforeEach, describe, expect, test, vi } from 'vitest'

const state = vi.hoisted(() => ({
    getModules: vi.fn(),
    unsubscribe: vi.fn(),
    callback: undefined as
        | undefined
        | ((value: Record<string, unknown>) => void),
    sConfig: {} as Record<string, unknown>,
    sSubscriptions: new Set<() => void>(),
}))
vi.mock('@revenge-mod/modules/finders', () => ({
    getModules: state.getModules,
}))
vi.mock('@revenge-mod/modules/finders/filters', () => ({
    withProps: (...props: string[]) => props,
}))
vi.mock('./modules/settings/_internal', () => ({
    sConfig: state.sConfig,
    sSubscriptions: state.sSubscriptions,
}))
beforeEach(() => {
    vi.resetModules()
    state.getModules.mockReset()
    state.unsubscribe.mockReset()
    state.callback = undefined
    state.sSubscriptions.clear()
    for (const key of Object.keys(state.sConfig))
        Reflect.deleteProperty(state.sConfig, key)
    state.getModules.mockImplementation((_filter, callback) => {
        state.callback = callback
        return state.unsubscribe
    })
})
describe('late settings registration', () => {
    test('uses lookup-plus-wait rather than future-only subscription', async () => {
        const module = await import('./start')
        expect(state.getModules).toHaveBeenCalledWith(
            ['SETTING_RENDERER_CONFIG'],
            expect.any(Function),
            { cached: true },
        )
        expect(module.sLoaded).toBe(false)
    })
    test('handles an already initialized match delivered after subscription returns', async () => {
        const module = await import('./start')
        const original = { discord: { title: 'Discord' } }
        const exports = { SETTING_RENDERER_CONFIG: original }
        const callback = vi.fn()
        state.sSubscriptions.add(callback)
        state.sConfig.revenge = { title: 'Revenge' }
        state.callback?.(exports)
        expect(module.sLoaded).toBe(true)
        expect(callback).toHaveBeenCalledTimes(1)
        expect(state.unsubscribe).toHaveBeenCalledTimes(1)
        expect(state.sSubscriptions.size).toBe(0)
        expect(exports.SETTING_RENDERER_CONFIG).toEqual({
            ...original,
            ...state.sConfig,
        })
    })
    test('preserves subsequent Discord renderer config assignments', async () => {
        await import('./start')
        const exports = {
            SETTING_RENDERER_CONFIG: { old: 1 } as Record<string, unknown>,
        }
        state.callback?.(exports)
        state.sConfig.revenge = 2
        exports.SETTING_RENDERER_CONFIG = { current: 3 }
        expect(exports.SETTING_RENDERER_CONFIG).toEqual({
            current: 3,
            revenge: 2,
        })
    })
})
