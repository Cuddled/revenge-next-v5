import { lookupModule } from '@revenge-mod/modules/finders'
import {
    allOf,
    withDependencies,
    withSingleProp,
} from '@revenge-mod/modules/finders/filters'
import {
    ReactJSXRuntimeModuleId,
    ReactModuleId,
    ReactNativeModuleId,
} from '@revenge-mod/react'
import { proxify } from '@revenge-mod/utils/proxy'
import { ImportTrackerModuleId } from './common/import-tracker'
import { TokensModuleId } from './common/tokens'
import { getDesignReadiness } from './design-ready'
import type { DiscordModules } from './types'

const { last, partial, relative, ordered } = withDependencies

export let Design: Design = proxify(
    () => {
        const result = getDesignReadiness()
        if (result.state === 'ready') return (Design = result.value)
        throw new Error('Compatibility fix v5: design module is not ready.')
    },
    { hint: {} },
)!

// design/components/Forms/native/FormSwitch.native.tsx
export let FormSwitch: DiscordModules.Components.FormSwitch = proxify(() => {
    const [module] = lookupModule(
        withSingleProp('FormSwitch')
            .and(
                withDependencies(
                    partial([
                        null,
                        ReactModuleId,
                        ReactNativeModuleId,
                        ReactJSXRuntimeModuleId,
                    ]),
                ).and(
                    withDependencies(
                        ordered([
                            TokensModuleId,
                            ordered([relative(1), ImportTrackerModuleId]),
                            [ImportTrackerModuleId],
                            ImportTrackerModuleId,
                        ]),
                    ),
                ),
            )
            .keyAs('revenge.discord.design.FormSwitch'),
    )

    if (module) return (FormSwitch = module.FormSwitch)
})!

export let FormRadio: DiscordModules.Components.FormRadio = proxify(() => {
    const [module] = lookupModule(
        withSingleProp('FormRadio')
            .and(
                allOf(
                    withDependencies(last([ImportTrackerModuleId])),
                    withDependencies(
                        ordered([
                            ReactModuleId,
                            ReactJSXRuntimeModuleId,
                            TokensModuleId,
                        ]),
                    ),
                ),
            )
            .keyAs('revenge.discord.design.FormRadio'),
    )

    if (module) return (FormRadio = module.FormRadio)
})!

export interface Design {
    createStyles: DiscordModules.Components.Styles.CreateStylesFunction
    useSegmentedControlState: DiscordModules.Components.UseSegmentedControlStateFunction
    useTooltip: DiscordModules.Components.UseTooltipFunction

    TextStyleSheet: DiscordModules.Components.Styles.TextStyleSheet

    ActionSheet: DiscordModules.Components.ActionSheet
    ActionSheetRow: DiscordModules.Components.ActionSheetRow
    ActionSheetSwitchRow: DiscordModules.Components.ActionSheetSwitchRow
    BottomSheet: DiscordModules.Components.BottomSheet
    BottomSheetTitleHeader: DiscordModules.Components.BottomSheetTitleHeader
    AlertActionButton: DiscordModules.Components.AlertActionButton
    AlertModal: DiscordModules.Components.AlertModal
    Button: DiscordModules.Components.Button
    Card: DiscordModules.Components.Card
    Checkbox: DiscordModules.Components.Checkbox
    ContextMenu: DiscordModules.Components.ContextMenu
    ContextMenuItem: DiscordModules.Components.ContextMenuItem
    FloatingActionButton: DiscordModules.Components.FloatingActionButton
    IconButton: DiscordModules.Components.IconButton
    ImageButton: DiscordModules.Components.ImageButton
    LayerScope: DiscordModules.Components.LayerScope
    NavigatorHeader: DiscordModules.Components.NavigatorHeader
    SegmentedControl: DiscordModules.Components.SegmentedControl
    SegmentedControlPages: DiscordModules.Components.SegmentedControlPages
    Stack: DiscordModules.Components.Stack
    Slider: DiscordModules.Components.Slider
    TableCheckboxRow: DiscordModules.Components.TableCheckboxRow
    TableRadioGroup: typeof DiscordModules.Components.TableRadioGroup
    TableRadioRow: typeof DiscordModules.Components.TableRadioRow
    TableRow: DiscordModules.Components.TableRow
    TableRowGroup: DiscordModules.Components.TableRowGroup
    TableSwitchRow: DiscordModules.Components.TableSwitchRow
    Tabs: DiscordModules.Components.Tabs
    Text: DiscordModules.Components.Text
    TextArea: DiscordModules.Components.TextArea
    TextField: DiscordModules.Components.TextField
    TextInput: DiscordModules.Components.TextInput
}
