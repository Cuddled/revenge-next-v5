import { beforeEach, describe, expect, test, vi } from 'vitest'

const runtime = vi.hoisted(() => ({
    lookup: vi.fn(),
    initialized: vi.fn(),
}))
vi.mock('./utils/modules/finders', () => ({
    lookupModuleWithImportedPath: runtime.lookup,
}))
vi.mock('@revenge-mod/modules/metro/utils', () => ({
    isModuleInitialized: runtime.initialized,
}))

import {
    checkDesignShape,
    DesignPath,
    DesignRequiredProperties,
    getDesignReadiness,
} from './design-ready'

function design() {
    return Object.fromEntries(
        DesignRequiredProperties.map(key => [key, () => {}]),
    )
}
beforeEach(() => {
    runtime.lookup.mockReset()
    runtime.initialized.mockReset()
})
describe('exact initialized design path', () => {
    test('waits when the path is absent', () => {
        runtime.lookup.mockReturnValue([undefined, undefined])
        expect(getDesignReadiness()).toEqual({
            state: 'pending',
            reason: 'path-missing',
        })
        expect(runtime.lookup).toHaveBeenCalledWith(DesignPath)
        expect(runtime.initialized).not.toHaveBeenCalled()
    })
    test('does not inspect exports of an uninitialized module', () => {
        const ownKeys = vi.fn(() => {
            throw new Error('must not inspect')
        })
        runtime.lookup.mockReturnValue([new Proxy({}, { ownKeys }), 15809])
        runtime.initialized.mockReturnValue(0)
        expect(getDesignReadiness()).toEqual({
            state: 'pending',
            reason: 'uninitialized',
        })
        expect(ownKeys).not.toHaveBeenCalled()
    })
    test('accepts the path without a hardcoded module ID', () => {
        const value = design()
        runtime.lookup.mockReturnValue([value, 9000])
        runtime.initialized.mockReturnValue(1)
        expect(getDesignReadiness()).toEqual({
            state: 'ready',
            value,
            id: 9000,
        })
        expect(runtime.initialized).toHaveBeenCalledWith(9000)
    })
    test('fails closed on an initialized empty namespace', () => {
        runtime.lookup.mockReturnValue([{}, 15809])
        runtime.initialized.mockReturnValue(1)
        expect(getDesignReadiness()).toEqual({
            state: 'invalid',
            reason: 'missing-TableRow',
            id: 15809,
        })
    })
})
describe('design export validation', () => {
    test.each([{}, [], new Date()])('rejects non-component objects', value => {
        expect(checkDesignShape({ ...design(), TableRow: value })).toBe(
            'type-TableRow',
        )
    })
    test.each(['react.forward_ref', 'react.lazy'])(
        'accepts recognized object components',
        type => {
            expect(
                checkDesignShape({
                    ...design(),
                    Text: { $$typeof: Symbol.for(type) },
                }),
            ).toBeUndefined()
        },
    )
    test.each([null, undefined, 0, 'private text', () => {}])(
        'rejects non-namespace %s',
        value => {
            expect(checkDesignShape(value)).toBe('namespace-type')
        },
    )
    test('accepts ordinary function exports', () => {
        expect(checkDesignShape(design())).toBeUndefined()
    })
    test('accepts object component exports', () => {
        const value = {
            ...design(),
            TableRow: { $$typeof: Symbol.for('react.memo') },
        }
        expect(checkDesignShape(value)).toBeUndefined()
    })
    test.each(DesignRequiredProperties)('rejects missing %s', key => {
        const value = design()
        Reflect.deleteProperty(value, key)
        expect(checkDesignShape(value)).toBe(`missing-${key}`)
    })
    test('rejects empty component exports', () => {
        expect(checkDesignShape({ ...design(), Button: null })).toBe(
            'type-Button',
        )
    })
    test('requires callable createStyles', () => {
        expect(checkDesignShape({ ...design(), createStyles: {} })).toBe(
            'type-createStyles',
        )
    })
    test('permits named re-export getters without calling component functions', () => {
        const value = design()
        const component = vi.fn()
        const getter = vi.fn(() => component)
        Object.defineProperty(value, 'Button', {
            get: getter,
            configurable: true,
        })
        expect(checkDesignShape(value)).toBeUndefined()
        expect(getter).toHaveBeenCalledTimes(1)
        expect(component).not.toHaveBeenCalled()
    })
    test('does not inspect unrelated getters', () => {
        const value = design()
        const unrelated = vi.fn(() => {
            throw new Error('private value')
        })
        Object.defineProperty(value, 'privateField', { get: unrelated })
        expect(checkDesignShape(value)).toBeUndefined()
        expect(unrelated).not.toHaveBeenCalled()
    })
    test('never exposes a throwing getter message', () => {
        const value = design()
        Object.defineProperty(value, 'Button', {
            get() {
                throw new Error('secret-token-marker')
            },
        })
        expect(checkDesignShape(value)).toBe('getter-Button')
    })
    test('rejects catch-all proxy descriptors', () => {
        const proxy = new Proxy(design(), {
            has: () => true,
            get: () => () => {},
        })
        expect(checkDesignShape(proxy)).toBe('catch-all')
    })
    test('rejects descriptor-only phantom keys', () => {
        const proxy = new Proxy(
            {},
            {
                getOwnPropertyDescriptor: () => ({
                    value: () => {},
                    configurable: true,
                }),
            },
        )
        expect(checkDesignShape(proxy)).toBe('missing-TableRow')
    })
    test('contains reflection errors', () => {
        const proxy = new Proxy(
            {},
            {
                ownKeys() {
                    throw new Error('private details')
                },
            },
        )
        expect(checkDesignShape(proxy)).toBe('inspection-failed')
    })
})
