import { isModuleInitialized } from '@revenge-mod/modules/metro/utils'
import { lookupModuleWithImportedPath } from './utils/modules/finders'
import type { Design } from './design'

export const DesignPath = 'design/native.tsx'
export const DesignRequiredProperties = [
    'TableRow',
    'Button',
    'AlertModal',
    'AlertActionButton',
    'Text',
    'createStyles',
] as const

export type DesignReadiness =
    | { state: 'pending'; reason: 'path-missing' | 'uninitialized' }
    | { state: 'invalid'; reason: string; id: number }
    | { state: 'ready'; value: Design; id: number }

/** Validates only named exports from the exact imported design module. */
export function checkDesignShape(value: unknown): string | undefined {
    if (value === null || typeof value !== 'object') return 'namespace-type'
    try {
        const keys = Reflect.ownKeys(value)
        const sentinel = Symbol()
        if (sentinel in value || Reflect.get(value, sentinel) !== undefined)
            return 'catch-all'
        for (const key of DesignRequiredProperties) {
            if (!keys.includes(key)) return `missing-${key}`
            const prop = Object.getOwnPropertyDescriptor(value, key)
            if (!prop) return `missing-${key}`
            let exported: unknown
            try {
                exported = Reflect.get(value, key)
            } catch {
                return `getter-${key}`
            }
            if (key === 'createStyles') {
                if (typeof exported !== 'function') return `type-${key}`
            } else if (typeof exported !== 'function') {
                if (exported === null || typeof exported !== 'object')
                    return `type-${key}`
                const marker = Object.getOwnPropertyDescriptor(
                    exported,
                    '$$typeof',
                )
                if (
                    !marker ||
                    !('value' in marker) ||
                    ![
                        Symbol.for('react.memo'),
                        Symbol.for('react.forward_ref'),
                        Symbol.for('react.lazy'),
                    ].includes(marker.value)
                )
                    return `type-${key}`
            }
        }
    } catch {
        return 'inspection-failed'
    }
}

/** Reads exact-path exports. Named re-export getters may run. */
export function getDesignReadiness(): DesignReadiness {
    const [value, id] = lookupModuleWithImportedPath<unknown>(DesignPath)
    if (id === undefined) return { state: 'pending', reason: 'path-missing' }
    if (!isModuleInitialized(id))
        return { state: 'pending', reason: 'uninitialized' }
    const reason = checkDesignShape(value)
    return reason
        ? { state: 'invalid', reason, id }
        : { state: 'ready', value: value as Design, id }
}
